<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Inicio | Shop Sports</title>

    <link rel="stylesheet" href="estilo.css">

</head>

<body>

<header>

    <h1>Shop Sports</h1>

    <nav>

        <ul>

            <li><a href="inicio.html">Inicio</a></li>

            <li><a href="productos.html">Productos</a></li>

            <li><a href="carrito.html">Carrito</a></li>

            <li><a href="perfil.html">Mi Perfil</a></li>

            <li><a href="login.html">Cerrar sesion</a></li>

        </ul>

    </nav>

</header>

<section class="banner">

    <h2>�Bienvenido a Shop Sports!</h2>

    <p>Encuentra los mejores artículos deportivos al mejor precio.</p>

</section>

<section class="busqueda">

    <input type="text" placeholder="Buscar productos...">

    <button>Buscar</button>

</section>

<section class="categorias">

    <h2>Categorias</h2>

    <div class="categoria">F�tbol</div>

    <div class="categoria">Baloncesto</div>

    <div class="categoria">Running</div>

    <div class="categoria">Gimnasio</div>

</section>

<section class="productos">

    <div class="producto">

        <img src="img/balon.jpg">

        <h3>Balón Profesional</h3>

        <p>$120.000</p>

        <button>Agregar al carrito</button>

    </div>

    <div class="producto">

        <img src="img/guayos.jpg">

        <h3>Guayos Nike</h3>

        <p>$350.000</p>

        <button>Agregar al carrito</button>

    </div>

    <div class="producto">

        <img src="img/camiseta.jpg">

        <h3>Camiseta Deportiva</h3>

        <p>$85.000</p>

        <button>Agregar al carrito</button>

    </div>

</section>

<footer>

    <p>© 2026 Shop Sports - Todos los derechos reservados.</p>

</footer>
    <a href="saludo servlet">probar metodo GET</a>
</body>

</html>