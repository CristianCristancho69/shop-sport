<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Login - ShopSports</title>
</head>
<body>

<h2>Inicio de Sesión</h2>

<form action="LoginServlet" method="post">

    <label>Usuario:</label><br>
    <input type="text" name="usuario" required><br><br>

    <label>Contraseña:</label><br>
    <input type="password" name="clave" required><br><br>

    <input type="submit" value="Iniciar Sesión">

</form>

</body>
</html>